$(document).ready(function(){
    $('#contact').addClass('nav-item-active')
    $('#contact a').css({'color':'#fff'})
})