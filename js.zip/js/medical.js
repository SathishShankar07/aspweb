$(document).ready(function(){
    $('#medical_billing').addClass('nav-item-active')
    $('#medical_billing a').css({'color':'#fff'})
})