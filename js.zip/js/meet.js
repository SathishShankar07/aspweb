$(document).ready(function(){
    $('#meet').addClass('nav-item-active')
    $('#meet a').css({'color':'#fff'})
})