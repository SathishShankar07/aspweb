$(document).ready(function(){
    $('#home').addClass('nav-item-active')  
    $('#home a').css({'color':'#fff'})
    $('.arrow').mouseover(function(){
        $('.arrow i').css({'transform':'translateX(7px)','transition':'0.2s'})
    })
    $('.arrow').mouseout(function(){
        $('.arrow i').css({'transform':'translateX(0px)','transition':'0.2s'})
    })
    $('#count-1').jQuerySimpleCounter({
        start:  0,
        end:    1000,
        duration: 4000
    });
    $('#count-2').jQuerySimpleCounter({
        start:  0,
        end:    2000,
        duration: 4000
    });

    $('#count-3').jQuerySimpleCounter({
        start:  0,
        end:    2200,
        duration: 4000
    });
    $('#count-4').jQuerySimpleCounter({
        start:  0,
        end:    1700,
        duration: 4000
    });

})


