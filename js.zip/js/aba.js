$(document).ready(function(){
    $('#aba_billing').addClass('nav-item-active')
    $('#aba_billing a').css({'color':'#fff'})
})


